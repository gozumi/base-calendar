var width = window.innerWidth,
	height = 500,
	cellSize = 40,
	top = 40,
	startX = -15600,
	shiftSize = cellSize * 52;
var day = d3.time.format("%w"),
	week = d3.time.format("%U"),
	month = d3.time.format('%B'),
	year = d3.time.format('%Y'),
	percent = d3.format(".1%"),
	format = d3.time.format("%Y-%m-%d"),
	fromYear = 2000,
	toYear = 2015;

var color = d3.scale.quantize().domain([-0.05, 0.05]).range(d3.range(11).map(function(d) {
	return "q" + d + "-11";
}));

var scale = d3.scale.linear().domain([0, 1]).range([0, 1]);


var svg = d3.select("body").append("svg").attr("width", width).attr("height", height).attr("class", "RdYlGn").append("g").attr("transform", "translate(" + startX + "," + top + ")");

var rect = svg.selectAll(".day").data(d3.time.days(new Date(fromYear, 0, 1), new Date(toYear + 1, 0, 1))).enter().append("rect").attr("class", "day").attr("width", cellSize).attr("height", cellSize).attr("x", function(d) {
	return(week(d) * cellSize) + weekOffset(d);
}).attr("y", function(d) {
	return day(d) * cellSize;
}).datum(format);

rect.append("title").text(function(d) {
	return d;
});







// var width = 960,
// 	height = 180,
// 	xSteps = d3.range(10, width, 16),
// 	ySteps = d3.range(10, height, 16);

var xFisheye = d3.fisheye.scale(d3.scale.identity).domain([0, width]).focus(360),
	yFisheye = d3.fisheye.scale(d3.scale.identity).domain([0, height]).focus(90);

// var svg = d3.select("#chart3").append("svg").attr("width", width).attr("height", height).append("g").attr("transform", "translate(-.5,-.5)");

// svg.append("rect").attr("class", "background").attr("width", width).attr("height", height);

// var xLine = svg.selectAll(".x").data(xSteps).enter().append("line").attr("class", "x").attr("y2", height);

// var yLine = svg.selectAll(".y").data(ySteps).enter().append("line").attr("class", "y").attr("x2", width);

// redraw();

svg.on("mousemove", function() {
	var mouse = d3.mouse(this);
	xFisheye.focus(mouse[0]);
	yFisheye.focus(mouse[1]);
	redraw();
});

function redraw() {
	rect.attr("width", xFisheye(cellSize)).attr("height", yFisheye(cellSize)).attr("x", function(d) {
		return xFisheye((week(d) * cellSize) + weekOffset(d));
	}).attr("y", function(d) {
		return yFisheye(day(d) * cellSize);
	});
}














var months = svg.selectAll(".month").data(d3.time.months(new Date(fromYear, 0, 1), new Date(toYear + 1, 0, 1))).enter().append("g").attr("class", "month");

months.append('path').attr('class', 'monthBound').attr('d', monthPath).attr("transform", function(d) {
	return "translate(" + monthOffset(d) + "," + 0 + ")";
});
months.append('text').attr('y', -10).attr('class', 'monthLabel').text(function(d) {
	return month(d) + ' ' + year(d);
}).attr('x', function(d) {
	return(week(d) * cellSize) + monthOffset(d) + cellSize + 5;
});

d3.csv("dji.csv", function(error, csv) {
	var data = d3.nest().key(function(d) {
		return d.Date;
	}).rollup(function(d) {
		return(d[0].Close - d[0].Open) / d[0].Open;
	}).map(csv);

	rect.filter(function(d) {
		return d in data;
	}).attr("class", function(d) {
		return "day " + color(data[d]);
	}).select("title").text(function(d) {
		return d + ": " + percent(data[d]);
	});
});

function monthPath(t0) {
	var t1 = new Date(t0.getFullYear(), t0.getMonth() + 1, 0),
		d0 = +day(t0),
		w0 = +week(t0),
		monthText = month(t0),
		//move this
		d1 = +day(t1),
		w1 = +week(t1);
	return "M" + (w0 + 1) * cellSize + "," + d0 * cellSize + "H" + w0 * cellSize + "V" + 7 * cellSize + "H" + w1 * cellSize + "V" + (d1 + 1) * cellSize + "H" + (w1 + 1) * cellSize + "V" + 0 + "H" + (w0 + 1) * cellSize + "Z";
}

function monthOffset(d) {
	var years = d3.range(fromYear, Number(year(d)));
	var accumuletedWeekNumber = 0;

	for(var i = 0; i < years.length; i++) {
		if(day(new Date(years[i] + 1, 0, 1)) == "0") {
			accumuletedWeekNumber = accumuletedWeekNumber + 1;
		}
		accumuletedWeekNumber = accumuletedWeekNumber + Number(week(new Date(years[i], 11, 31)));
	}
	return accumuletedWeekNumber * cellSize;
}

function weekOffset(d) {
	var years = d3.range(fromYear, Number(year(d)));
	var accumuletedWeekNumber = 0;

	for(var i = 0; i < years.length; i++) {
		if(day(new Date(years[i] + 1, 0, 1)) == "0") {
			accumuletedWeekNumber = accumuletedWeekNumber + 1;
		}
		accumuletedWeekNumber = accumuletedWeekNumber + Number(week(new Date(years[i], 11, 31)));
	}
	return accumuletedWeekNumber * cellSize;
}

d3.select("div.forward").on("click", function() {
	startX = startX - shiftSize;
	svg.transition().duration(500).attr("transform", "translate(" + startX + "," + top + ")");
});
d3.select("div.backward").on("click", function() {
	startX = startX + shiftSize;
	svg.transition().duration(500).attr("transform", "translate(" + startX + "," + top + ")");
});

//d3.select(self.frameElement).style("height", "2910px");
d3.select('p.zoomin').on('click', function() {
	scale.range([0, 2]);
	var days = d3.selectAll('rect');
	var months = d3.selectAll('.monthBound');

	days.transition().duration(1000).attr('width', scale(cellSize)).attr('height', scale(cellSize)).attr('x', function(d) {
		var cellDateArray = d.split('-');
		var cellDate = new Date(cellDateArray[0], cellDateArray[1], cellDateArray[2]);
		var weekNumber = Number(week(cellDate));
		return(weekNumber * scale(cellSize)) + weekOffset(cellDate);
	}).attr('y', function(d) {
		var cellDateArray = d.split('-');
		var cellDate = new Date(cellDateArray[0], cellDateArray[1], cellDateArray[2]);
		return day(cellDate) * scale(cellSize);
	});

	months.transition().duration(1000).attr('transform', 'scale(2)');

	months.transition().duration(1000).attr("transform", function(d) {
		return "translate(" + scale(monthOffset(d)) + "," + 0 + ")";
	});
});

d3.select('p.zoomout').on('click', function() {
	scale.range([0, 1]);
	var days = d3.selectAll('rect');
	var months = d3.selectAll('.monthBound');

	days.transition().duration(1000).attr('width', scale(cellSize)).attr('height', scale(cellSize)).attr('x', function(d) {
		var cellDateArray = d.split('-');
		var cellDate = new Date(cellDateArray[0], cellDateArray[1], cellDateArray[2]);
		var weekNumber = Number(week(cellDate));
		return(weekNumber * scale(cellSize)) + weekOffset(cellDate);
	}).attr('y', function(d) {
		var cellDateArray = d.split('-');
		var cellDate = new Date(cellDateArray[0], cellDateArray[1], cellDateArray[2]);
		return day(cellDate) * scale(cellSize);
	});

	months.transition().duration(1000).attr('transform', 'scale(2)');

	months.transition().duration(1000).attr("transform", function(d) {
		return "translate(" + scale(monthOffset(d)) + "," + 0 + ")";
	});
});











